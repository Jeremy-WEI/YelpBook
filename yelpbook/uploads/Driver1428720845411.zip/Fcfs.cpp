#include "Task.h"
#include <iostream> 
#include <algorithm>
#include <vector>

bool compare(const Task& task1, const Task& task2) {
	return task1.arrival < task2.arrival;
}

void fcfs(std::vector<Task> tasks) {
	std::sort(tasks.begin(), tasks.end(), compare);
	// for(std::vector<Task>::iterator it=tasks.begin(); it != tasks.end(); it++) {
	// 	std::cout << it->name << "\n"; //to test sort correctness
	// }
	
	int exec = 0; //points to the task currently being executed or to be executed
	int add = 0; //points to the task to be added to task queue next
	int finish = -1; //points to the task that is already finished
	bool it_added = false;//whether the task pointed by iterator has been added to task queue
	bool it_start = false;//whether the task pointed by iterator has started execution
	//loop on time
	int time = 0;
	int waiting = 0;
	for(time = 0; exec < tasks.size(); time++) {
		while(tasks[add].arrival == time) {
			std::cout << time << ": Adding task " << tasks[add].name << std::endl;
			add++;
		}
		if(tasks[exec].remaining == 0) {
			std::cout << time << ": Finished task " << tasks[exec].name << std::endl;
			finish = exec;
			exec++;
		} 
		if(exec < add && exec > finish) { //executing, time remaining reduced
			if(tasks[exec].remaining == tasks[exec].time) {
				waiting += (time - tasks[exec].arrival);
				std::cout << time << ": Running task " << tasks[exec].name << std::endl;
			}
			tasks[exec].remaining--;
		}
		
	}
	std::cout << time - 1 << ": All tasks finished" << std::endl;
	std::cout << "Average waiting time: " << ((double) waiting) / tasks.size() << std::endl;
}



